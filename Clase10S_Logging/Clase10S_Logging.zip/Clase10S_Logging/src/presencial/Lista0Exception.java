package presencial;

public class Lista0Exception extends Exception{

    public Lista0Exception(String mensaje) {
        super(mensaje);
    }

}
