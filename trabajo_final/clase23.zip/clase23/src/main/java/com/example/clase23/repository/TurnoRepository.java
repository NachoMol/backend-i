package com.example.clase23.repository;

import com.example.clase23.entities.Paciente;
import com.example.clase23.entities.Turno;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface TurnoRepository  extends JpaRepository<Turno,Long> {
}
