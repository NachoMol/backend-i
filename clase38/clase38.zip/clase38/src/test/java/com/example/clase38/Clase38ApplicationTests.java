package com.example.clase38;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clase38ApplicationTests {

	@Test
	void contextLoads() {
	}

}
