package com.example.clase38;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase38Application {

	public static void main(String[] args) {
		SpringApplication.run(Clase38Application.class, args);
	}

}
