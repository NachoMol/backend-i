package mesa;

public interface Buscar {

    String buscarViaje(String ciudadHotel, Integer fechaSalida, Integer fechaRegreso);

}
