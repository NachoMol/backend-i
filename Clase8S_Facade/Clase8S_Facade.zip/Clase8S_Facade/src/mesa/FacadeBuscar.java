package mesa;

public class FacadeBuscar implements Buscar{


    @Override
    public String buscarViaje(String ciudadHotel, Integer fechaSalida, Integer fechaRegreso) {
        ApiVuelo.;
    }
}
