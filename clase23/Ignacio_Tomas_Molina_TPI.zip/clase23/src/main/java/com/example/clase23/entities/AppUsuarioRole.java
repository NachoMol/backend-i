package com.example.clase23.entities;

public enum AppUsuarioRole {
    ROLE_USER,ROLE_ADMIN
}
